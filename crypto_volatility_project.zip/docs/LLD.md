# Low-Level Design (LLD)

## src/preprocess.py
- load_data(path): read CSV
- basic_clean(df): normalize columns, ensure required cols
- handle_missing(df): per-symbol forward/backfill and median fill
- scale_numeric(df): standard scaling helper

## src/features.py
- add_basic_features: returns, log returns
- add_rolling_features: rolling std and MA for multiple windows
- add_liquidity: volume/market_cap
- add_technical: bollinger bands, ATR (ta library)
- create_target_volatility: target = future rolling std of log returns

## src/train.py
- time_split: keep last N days as test
- train_model: RandomForest
- evaluate: RMSE/MAE/R2

## app/streamlit_app.py
- load artifacts and let user pick symbol/date for prediction
