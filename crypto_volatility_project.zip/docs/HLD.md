# High-Level Design (HLD)

## Overview
Predict cryptocurrency volatility using historical OHLC, volume and market cap.

## Components
- Data Ingestion: CSV loader (`src/preprocess.py`)
- Preprocessing: cleaning and scaling
- Feature Engineering: rolling volatility, liquidity, technical indicators (`src/features.py`)
- Modeling: training script `src/train.py` (RandomForest by default)
- Evaluation: `src/evaluate.py` produces metrics and plots
- Deployment: Streamlit app `app/streamlit_app.py`

## Data Flow
CSV -> preprocess -> features -> train -> artifacts (model, metrics, plots) -> app
