# Final Report - Cryptocurrency Volatility Prediction
(Provide this file after running the pipeline and filling results.)

## Summary
- Objective: Predict short-term volatility for cryptocurrencies
- Dataset: Historical OHLCV + market cap for 50+ symbols

## Methodology
1. Data cleaning and imputation
2. Feature engineering (rolling volatility, MA, liquidity ratios, Bollinger, ATR)
3. Model: RandomForestRegressor
4. Evaluation: RMSE, MAE, R2

## Results
- Add metrics from artifacts/metrics.json
- Add plots from artifacts/

## Insights
- Briefly discuss which features were important, trends observed, and recommended next steps.
