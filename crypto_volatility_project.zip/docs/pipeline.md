# Pipeline Architecture
1. Read CSV dataset
2. Clean & handle missing values
3. Feature engineering (rolling stats, technical indicators)
4. Split data by time (train/test)
5. Train model and save artifacts
6. Evaluate on test set and create visualizations
7. Deploy a small Streamlit app to test predictions
