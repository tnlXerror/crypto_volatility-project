# Cryptocurrency Volatility Prediction
This repository contains a full end-to-end project to predict cryptocurrency volatility using historical OHLC, volume and market cap data.

## Contents
- `data/` - place your CSV dataset here (not included). Expected filename: `crypto_prices.csv`
- `src/` - source code: preprocessing, feature engineering, modelling, evaluation
- `app/` - Streamlit app for local testing
- `notebooks/` - example notebook (optional)
- `docs/` - HLD, LLD, Pipeline and Final Report
- `requirements.txt` - Python dependencies

## Quickstart
1. Put your dataset CSV at `data/crypto_prices.csv`
2. Create a virtualenv and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate   # or venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```
3. Run preprocessing & training:
   ```bash
   python src/train.py --data_path data/crypto_prices.csv --out_dir artifacts
   ```
4. Serve the app locally:
   ```bash
   streamlit run app/streamlit_app.py --server.port 8501
   ```

See docs/ for HLD, LLD and pipeline description.
