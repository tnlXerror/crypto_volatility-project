"""train.py
Train a regression model (XGBoost / RandomForest) to predict target_vol.
This script performs a time-aware split and saves the trained model and basic metrics.
"""
import pandas as pd, numpy as np, os, joblib, json
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, GridSearchCV, TimeSeriesSplit
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

def load_features(path):
    df = pd.read_csv(path, parse_dates=['date'])
    return df

def time_split(df, test_size_days=90):
    # Keep last N days as test set per symbol
    df = df.sort_values('date')
    last_date = df['date'].max()
    cutoff = last_date - pd.Timedelta(days=test_size_days)
    train = df[df['date'] <= cutoff].copy()
    test = df[df['date'] > cutoff].copy()
    return train, test

def train_model(train_df, features, target='target_vol'):
    X = train_df[features].values
    y = train_df[target].values
    model = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1)
    model.fit(X, y)
    return model

def evaluate(model, df, features, target='target_vol'):
    X = df[features].values
    y = df[target].values
    preds = model.predict(X)
    return {
        'rmse': mean_squared_error(y, preds, squared=False),
        'mae': mean_absolute_error(y, preds),
        'r2': r2_score(y, preds)
    }

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--features', required=True)
    parser.add_argument('--out_dir', default='artifacts')
    args = parser.parse_args()

    df = load_features(args.features)
    # Select numeric features for modeling - drop identifiers
    drop_cols = ['date','symbol','target_vol']
    features = [c for c in df.columns if c not in drop_cols and df[c].dtype in [float, int]]
    train_df, test_df = time_split(df)
    model = train_model(train_df, features)
    os.makedirs(args.out_dir, exist_ok=True)
    joblib.dump(model, os.path.join(args.out_dir,'model.joblib'))
    # Save features list
    with open(os.path.join(args.out_dir,'features.json'),'w') as f:
        json.dump(features,f)
    train_metrics = evaluate(model, train_df, features)
    test_metrics = evaluate(model, test_df, features)
    with open(os.path.join(args.out_dir,'metrics.json'),'w') as f:
        json.dump({'train':train_metrics,'test':test_metrics}, f, indent=2)
    print('Training complete. Metrics saved to', args.out_dir)
    print('Train metrics:', train_metrics)
    print('Test metrics:', test_metrics)
