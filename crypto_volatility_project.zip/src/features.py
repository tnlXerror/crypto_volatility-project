"""features.py
Feature engineering for volatility prediction.
Creates returns, rolling volatility, moving averages, liquidity ratios and technical indicators.
"""
import pandas as pd
import numpy as np
from ta.volatility import BollingerBands, AverageTrueRange

def add_basic_features(df):
    df = df.copy()
    # Intraday returns
    df['return'] = df.groupby('symbol')['close'].pct_change()
    df['log_return'] = np.log1p(df['return'])
    return df

def add_rolling_features(df, windows=[7,14,21]):
    df = df.copy()
    for w in windows:
        df[f'vol_roll_{w}'] = df.groupby('symbol')['log_return'].rolling(window=w).std().reset_index(level=0, drop=True)
        df[f'ma_close_{w}'] = df.groupby('symbol')['close'].rolling(window=w).mean().reset_index(level=0, drop=True)
        df[f'volatility_ratio_{w}'] = df[f'vol_roll_{w}'] / (df[f'vol_roll_{w}'].mean()+1e-9)
    return df

def add_liquidity(df):
    df = df.copy()
    df['liq_ratio'] = df['volume'] / (df['market_cap'] + 1e-9)
    return df

def add_technical(df):
    df = df.copy()
    # Bollinger Bands on close (ta requires non-scaled close values; ensure your close is raw)
    try:
        bb = BollingerBands(close=df['close'], window=20, window_dev=2)
        df['bb_upper'] = bb.bollinger_hband()
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_mid'] = bb.bollinger_mavg()
    except Exception:
        df['bb_upper'] = df['close']
        df['bb_lower'] = df['close']
        df['bb_mid'] = df['close']
    try:
        atr = AverageTrueRange(high=df['high'], low=df['low'], close=df['close'], window=14)
        df['atr'] = atr.average_true_range()
    except Exception:
        df['atr'] = np.nan
    return df

def create_target_volatility(df, target_window=7):
    df = df.copy()
    # We define the target: rolling standard deviation of log returns over target_window days (future volatility)
    df['target_vol'] = df.groupby('symbol')['log_return'].rolling(window=target_window).std().shift(-target_window).reset_index(level=0, drop=True)
    return df

def build_features_pipeline(df):
    df = add_basic_features(df)
    df = add_rolling_features(df)
    df = add_liquidity(df)
    df = add_technical(df)
    df = create_target_volatility(df)
    # Drop NaNs
    df = df.dropna(subset=['target_vol'])
    return df

if __name__ == '__main__':
    import argparse, os
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', default='artifacts/features.csv')
    args = parser.parse_args()
    df = pd.read_csv(args.input, parse_dates=['date'])
    df = build_features_pipeline(df)
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    df.to_csv(args.output, index=False)
    print('Saved features to', args.output)
