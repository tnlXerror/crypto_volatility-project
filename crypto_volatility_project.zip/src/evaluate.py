"""evaluate.py
Load model and compute evaluation metrics and some plots (saves PNGs)
"""
import pandas as pd, joblib, json, os
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

def load_all(features_csv, model_path, features_json):
    df = pd.read_csv(features_csv, parse_dates=['date'])
    model = joblib.load(model_path)
    with open(features_json,'r') as f:
        features = json.load(f)
    return df, model, features

def evaluate_and_plot(df, model, features, out_dir='artifacts'):
    os.makedirs(out_dir, exist_ok=True)
    # simple time-wise plot for one symbol (top symbol)
    top_symbol = df['symbol'].value_counts().index[0]
    df_sym = df[df['symbol']==top_symbol].sort_values('date')
    X = df_sym[features].values
    y = df_sym['target_vol'].values
    preds = model.predict(X)
    # metrics
    metrics = {
        'rmse': mean_squared_error(y,preds, squared=False),
        'mae': mean_absolute_error(y,preds),
        'r2': r2_score(y,preds)
    }
    # plot
    plt.figure(figsize=(10,4))
    plt.plot(df_sym['date'], y, label='target_vol')
    plt.plot(df_sym['date'], preds, label='pred')
    plt.legend()
    plt.title(f'Pred vs Actual for {top_symbol}')
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir,f'pred_vs_actual_{top_symbol}.png'))
    plt.close()
    # save metrics JSON
    with open(os.path.join(out_dir,'eval_metrics.json'),'w') as f:
        json.dump(metrics, f, indent=2)
    print('Evaluation complete. Plots and metrics saved to', out_dir)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--features_csv', required=True)
    parser.add_argument('--model', required=True)
    parser.add_argument('--features_json', required=True)
    parser.add_argument('--out_dir', default='artifacts')
    args = parser.parse_args()
    df, model, features = load_all(args.features_csv, args.model, args.features_json)
    evaluate_and_plot(df, model, features, args.out_dir)
