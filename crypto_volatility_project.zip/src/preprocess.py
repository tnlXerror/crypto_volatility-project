"""preprocess.py
Functions to load, clean and preprocess the cryptocurrency dataset.
Expected input CSV columns: date,symbol,open,high,low,close,volume,market_cap
"""
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

def load_data(path):
    df = pd.read_csv(path, parse_dates=['date'], low_memory=False)
    return df

def basic_clean(df):
    # Lowercase columns
    df = df.copy()
    df.columns = [c.strip().lower() for c in df.columns]
    # Ensure required columns exist
    required = ['date','symbol','open','high','low','close','volume','market_cap']
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    # Sort
    df = df.sort_values(['symbol','date']).reset_index(drop=True)
    return df

def handle_missing(df):
    df = df.copy()
    # Replace 0 or negative market caps/volumes with NaN
    df.loc[df['volume'] <= 0, 'volume'] = np.nan
    df.loc[df['market_cap'] <= 0, 'market_cap'] = np.nan
    # Forward fill per symbol then fill remaining with median
    df[['open','high','low','close','volume','market_cap']] = df.groupby('symbol')[['open','high','low','close','volume','market_cap']].apply(lambda g: g.ffill().bfill())
    # If still missing, fill with column median
    df[['open','high','low','close','volume','market_cap']] = df[['open','high','low','close','volume','market_cap']].fillna(df.median())
    return df

def scale_numeric(df, cols=None):
    df = df.copy()
    if cols is None:
        cols = ['open','high','low','close','volume','market_cap']
    scaler = StandardScaler()
    df[cols] = scaler.fit_transform(df[cols])
    return df, scaler

if __name__ == '__main__':
    import argparse, os
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', required=True)
    parser.add_argument('--out_path', default='artifacts/cleaned.csv')
    args = parser.parse_args()
    df = load_data(args.data_path)
    df = basic_clean(df)
    df = handle_missing(df)
    os.makedirs(os.path.dirname(args.out_path), exist_ok=True)
    df.to_csv(args.out_path, index=False)
    print('Saved cleaned data to', args.out_path)
