"""Simple Streamlit app to load model and make predictions for a chosen symbol & date.
"""
import streamlit as st
import pandas as pd, joblib, json, os, numpy as np
from datetime import datetime

st.title('Cryptocurrency Volatility Predictor - Demo')

st.sidebar.markdown('## Load artifacts')
model_path = st.sidebar.text_input('Model path', 'artifacts/model.joblib')
features_path = st.sidebar.text_input('Features CSV', 'artifacts/features.csv')
features_json = st.sidebar.text_input('Features JSON', 'artifacts/features.json')

if os.path.exists(model_path) and os.path.exists(features_path) and os.path.exists(features_json):
    model = joblib.load(model_path)
    df = pd.read_csv(features_path, parse_dates=['date'])
    with open(features_json,'r') as f:
        features = json.load(f)
    st.success('Artifacts loaded')
    symbol = st.selectbox('Symbol', df['symbol'].unique().tolist())
    date = st.date_input('Date', value=df['date'].max().date())
    # fetch last row for symbol on or before date
    row = df[(df['symbol']==symbol) & (df['date']<=pd.to_datetime(date))].sort_values('date').tail(1)
    if row.shape[0]==0:
        st.warning('No data for this symbol/date')
    else:
        X = row[features].values
        pred = model.predict(X)[0]
        st.write('Predicted future volatility (target window std of log returns):', float(pred))
        st.write('Row used for prediction:')
        st.dataframe(row[features + ['date','symbol']].T)
else:
    st.info('Provide valid paths to model and features to enable prediction.')
