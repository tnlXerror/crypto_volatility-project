#!/bin/bash
# Example run: adjust paths as needed
python src/preprocess.py --data_path data/crypto_prices.csv --out_path artifacts/cleaned.csv
python src/features.py --input artifacts/cleaned.csv --output artifacts/features.csv
python src/train.py --features artifacts/features.csv --out_dir artifacts
python src/evaluate.py --features_csv artifacts/features.csv --model artifacts/model.joblib --features_json artifacts/features.json --out_dir artifacts
echo "Artifacts produced in artifacts/"
